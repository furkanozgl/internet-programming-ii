<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>News Portal - @yield('title')</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
</head>
<body>

<div class="container mt-5">
    <div class="row mb-5">
        <div class="col-12" style="background: #86cfda; border-radius: 10px; padding: 30px;">
            <h1><a href="/db/select" style="color: white; text-decoration: none; font-weight: bold;">DPÜ - News Portal</a></h1>
        </div>
    </div>

    <div class="row mb-5">
        <div class="col-8">
            @yield('content')
        </div>
        <div class="col-4">
            <div class="list-group">
                @foreach(App\Models\Category::orderBy('order')->get() as $category)
                    <a class="list-group-item @if(isset($category_id) && $category->id == $category_id) active @endif"
                       href="/db/category/{{ $category->id }}"
                    >
                        {{ $category->name }}
                    </a>
                @endforeach

                <a class="list-group-item" href="/db/add">Add News</a>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col text-center" style="background: #86cfda; border-radius: 10px; padding: 10px;">Copyright &copy; 2023 Kütahya Teknik Bilimler Meslek Yüksekokulu</div>
    </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js" integrity="sha384-qKXV1j0HvMUeCBQ+QVp7JcfGl760yU08IQ+GpUo5hlbpg51QRiuqHAJz8+BrxE/N" crossorigin="anonymous"></script>
</body>
</html>
