<html>
<head>
    <meta charset="utf-8">
    <title>Mail</title>
</head>
<body>
<h1>Siparişiniz Kargolandı</h1>
<p>Sayın {{ $firstName }} {{ $lastName }},</p>
<p>Kargo takibi için PTT sorgulama sistemi üzerinden {{ $trackingNumber }} takip numarasını kullanabilirsiniz.</p>
</body>
</html>
