<?php

namespace App\Http\Controllers;

use App\Mail\OrderShipped;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Cache;

class CacheController extends Controller
{
    public function test()
    {
        // Facade
        Mail::to('murat.sari@dpu.edu.tr')->send(new OrderShipped());
    }
}
