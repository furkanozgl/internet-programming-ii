<?php

namespace App\Http\Controllers;

use App\Models\News;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class DBController extends Controller
{
    public function select()
    {
        $news = News::orderBy('id', 'DESC')->paginate(10);

        return view('db.select', [
            'news' => $news,
        ]);
    }

    public function category(Request $request, int $id)
    {
        $news = Category::findOrFail($id)
            ->news()
            ->orderBy('id', 'DESC')
            ->paginate(10);;

        return view('db.select', [
            'category_id' => $id,
            'news' => $news,
        ]);
    }

    public function detail(Request $request, int $id)
    {
        $news = News::findOrFail($id);

        Log::info('Haber görüntülendi', [
            'id' => $id,
            'ip' => $request->getClientIp(),
        ]);

        return view('db.detail', [
           'news' => $news,
        ]);
    }

    public function add()
    {
        $categories = Category::orderBy('order')->get();

        return view('db.add', [
            'categories' => $categories,
        ]);
    }

    public function insert(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'title' => 'required|min:5|max:255|unique:news,title',
            'summary' => 'required',
            'content' => 'required|min:40',
            'category_id' => 'required|numeric|exists:categories,id'
        ]);

        if ($validator->fails()) {
            return redirect('/db/add')
                ->withErrors($validator)
                ->withInput();
        }

        $news = new News();
        $news->category_id = $request->get('category_id');
        $news->title = $request->get('title');
        $news->summary = $request->get('summary');
        $news->content = $request->get('content');
        $news->save();

        return response()->redirectTo('/db/select');
    }

    public function delete(Request $request, int $id)
    {
        $news = News::findOrFail($id);
        $news->delete();

        return response()->redirectTo('/db/select');
    }

    public function edit(Request $request, int $id)
    {
        $newsDetail = News::findOrFail($id);

        $categories = Category::orderBy('order')->get();

        return view('db.edit', [
            'newsDetail' => $newsDetail,
            'categories' => $categories,
        ]);
    }

    public function update(Request $request, int $id)
    {
        $validator = Validator::make($request->all(), [
            'title' => 'required|min:5|max:255|unique:news,title,' . $id,
            'summary' => 'required',
            'content' => 'required|min:40',
            'category_id' => 'required|numeric|exists:categories,id',
        ]);

        if ($validator->fails()) {
            return redirect('/db/edit/' . $id)
                ->withErrors($validator)
                ->withInput();
        }

        $news = News::findOrFail($id);

        $news->title = $request->get('title');
        $news->summary = $request->get('summary');
        $news->content = $request->get('content');
        $news->category_id = $request->get('category_id');


        return response()->redirectTo('/db/detail/' . $id);
    }
}
