<?php $__env->startSection('title', 'Add News'); ?>

<?php $__env->startSection('content'); ?>

    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newsItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h3><?php echo e($newsItem->title); ?></h3>
        <p><?php echo e($newsItem->summary); ?></p>

        <a href="/db/detail/<?php echo e($newsItem->id); ?>" class="btn btn-outline-primary">Detaylar >></a>
        <hr />
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php echo e($news->links()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/muratsari/dpu/IP2-H3/project/resources/views/db/select.blade.php ENDPATH**/ ?>