<?php $__env->startSection('title', 'Add News'); ?>

<?php $__env->startSection('content'); ?>
    <?php if($errors->isNotEmpty()): ?>
        <div class="alert alert-danger" role="alert">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <form method="post" action="/db/edit/<?php echo e($newsDetail->id); ?>">
        <?php echo csrf_field(); ?>
        <label>Category</label>
        <select name="category_id" class="form-control mb-5">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>" <?php if($category->id == $newsDetail->category_id): ?> selected <?php endif; ?>><?php echo e($category->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <label>Title</label>
        <input class="form-control <?php if(in_array('title', $errors->keys())): ?>is-invalid <?php endif; ?>" type="text" name="title" placeholder="Title" value="<?php echo e(old('title', $newsDetail->title)); ?>" /> <br /><br />

        <label>Summary</label>
        <textarea style="height: 150px;" class="form-control <?php if(in_array('summary', $errors->keys())): ?>is-invalid <?php endif; ?>" name="summary" placeholder="Summary"><?php echo e(old('summary', $newsDetail->summary)); ?></textarea> <br /><br />

        <label>Content</label>
        <textarea style="height: 300px;" class="form-control <?php if(in_array('content', $errors->keys())): ?>is-invalid <?php endif; ?>" name="content" placeholder="Content"><?php echo e(old('content', $newsDetail->content)); ?></textarea> <br /><br />
        <input class="btn btn-primary" type="submit" value="Update News!">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/muratsari/dpu/IP2-H3/project/resources/views/db/edit.blade.php ENDPATH**/ ?>