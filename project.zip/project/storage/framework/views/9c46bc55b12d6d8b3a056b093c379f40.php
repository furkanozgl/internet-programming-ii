<?php $__env->startSection('title', 'Add News'); ?>

<?php $__env->startSection('content'); ?>
    <h1 style="color: #2d3748"><?php echo e($news->title); ?> <span class="badge bg-info"><?php echo e($news->category->name); ?></span> </h1>

    <p style="text-decoration: underline; color: #0c5460;"><?php echo e($news->summary); ?></p>

    <p><?php echo e($news->content); ?></p>


    <a class="btn btn-outline-danger" href="/db/delete/<?php echo e($news->id); ?>">Haberi Sil!</a>
    <a class="btn btn-outline-warning" href="/db/edit/<?php echo e($news->id); ?>">Haberi Düzenle!</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/muratsari/dpu/IP2-H3/project/resources/views/db/detail.blade.php ENDPATH**/ ?>