<html>
<head>
    <meta charset="utf-8">
    <title>Mail</title>
</head>
<body>
<h1>Siparişiniz Kargolandı</h1>
<p>Sayın <?php echo e($firstName); ?> <?php echo e($lastName); ?>,</p>
<p>Kargo takibi için PTT sorgulama sistemi üzerinden <?php echo e($trackingNumber); ?> takip numarasını kullanabilirsiniz.</p>
</body>
</html>
<?php /**PATH /Users/muratsari/dpu/IP2-H3/project/resources/views/mail/order-shipped.blade.php ENDPATH**/ ?>