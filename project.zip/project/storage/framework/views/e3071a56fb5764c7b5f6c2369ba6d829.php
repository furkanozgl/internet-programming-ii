<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>News Portal - <?php echo $__env->yieldContent('title'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
</head>
<body>

<div class="container mt-5">
    <div class="row mb-5">
        <div class="col-12" style="background: #86cfda; border-radius: 10px; padding: 30px;">
            <h1><a href="/db/select" style="color: white; text-decoration: none; font-weight: bold;">DPÜ - News Portal</a></h1>
        </div>
    </div>

    <div class="row mb-5">
        <div class="col-8">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <div class="col-4">
            <div class="list-group">
                <?php $__currentLoopData = App\Models\Category::orderBy('order')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="list-group-item <?php if(isset($category_id) && $category->id == $category_id): ?> active <?php endif; ?>"
                       href="/db/category/<?php echo e($category->id); ?>"
                    >
                        <?php echo e($category->name); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <a class="list-group-item" href="/db/add">Add News</a>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col text-center" style="background: #86cfda; border-radius: 10px; padding: 10px;">Copyright &copy; 2023 Kütahya Teknik Bilimler Meslek Yüksekokulu</div>
    </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js" integrity="sha384-qKXV1j0HvMUeCBQ+QVp7JcfGl760yU08IQ+GpUo5hlbpg51QRiuqHAJz8+BrxE/N" crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH /Users/muratsari/dpu/IP2-H3/project/resources/views/layouts/app.blade.php ENDPATH**/ ?>