<?php
function response($input)
{
//Insert your code here
    $response = [];
    for ($i = 1; $i <= $input; $i++) {
        if ($i % 3 == 0 && $i % 5 == 0) {
            array_push($response, 'FizzBuzz');
        } else if ($i % 3 == 0) {
            array_push($response, 'Fizz');
        } else if ($i % 5 == 0) {
            array_push($response, 'Buzz');
        } else {
            array_push($response, $i);
        }
    }
    return $response;
}

function findNumericalPalindromes($count, $i) {
    $results = [];

    do {
        if (isPalindrome($i)) {
            $results[] = $i;
        }

        $i++;
    } while(count($results) < $count);

    return $results;
}

function isPalindrome($number) {
    return !($number <= 10) && strrev((string) $number) == (string) $number;
}

function sum_of_digits($dob) {
    $sum = 0;
    for ($i=0; $i<strlen($dob); $i++) {
        $sum += (int) $dob[$i];
    }
    return $sum;
}

/*
 
 * I am confident in my technical skills. I will do my best to perform above what is expected of me.

Every successful programmer is, of course, a perfectionist. But the perfect is also the enemy of the good.
I do not directly answer this question. It is better to act according to what my company needs at that moment.

Sometimes you need to do an excellent job, and sometimes you have to do more work at an acceptable level.
 */
